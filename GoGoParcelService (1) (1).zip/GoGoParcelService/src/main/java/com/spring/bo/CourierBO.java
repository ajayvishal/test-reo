package com.spring.bo;

import com.spring.model.Courier;

public class CourierBO  {
	
	public double calculateCourierCharge(Courier cObj,String city) {
	   
		double courierCharge=0.0;
		//fill the code
	    return courierCharge;
	}

}
