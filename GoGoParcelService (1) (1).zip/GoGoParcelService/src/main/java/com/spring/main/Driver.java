package com.spring.main;

import com.spring.exception.InvalidParcelWeightException;
import com.spring.service.CourierService;

public class Driver {

	public static void main(String[] args) {
	    
		//fill the code
	}

}
