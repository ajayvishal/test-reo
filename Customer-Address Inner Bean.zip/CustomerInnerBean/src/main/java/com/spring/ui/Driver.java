package com.spring.ui;
     
     import com.spring.app.Address;
     import com.spring.app.AddressBook;
     import java.util.*;
     
    import org.springframework.context.ApplicationContext;
     import org.springframework.context.support.ClassPathXmlApplicationContext;
     
   public class Driver {
    
      public static AddressBook loadAddressBook() {
                ApplicationContext con = new ClassPathXmlApplicationContext("applicationContext.xml");
                AddressBook adres = (AddressBook) con.getBean("addbook");
                return adres;
       }
    
      public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);
                AddressBook abook=loadAddressBook();
                System.out.println("Enter the temporary address");
                System.out.println("Enter the house name");
               String hname = sc.nextLine();
              System.out.println("Enter the street");
               String stret = sc.nextLine();
                System.out.println("Enter the city");
              String cty = sc.nextLine();
               System.out.println("Enter the state");
              String stat = sc.nextLine();
                System.out.println("Enter the phone number");
                String pno = sc.next();
                Address ad = new Address();
                ad.setCity(cty);
                ad.setState(stat);
             ad.setStreet(stret);
                ad.setHouseName(hname);
               
                abook.setPhoneNumber(pno);
                
               System.out.println("Temporary address");
                System.out.println("House name:"+ad.getHouseName());
               System.out.println("Street:"+ad.getStreet());
               System.out.println("City:"+ad.getCity());
                System.out.println("State:"+ad.getState());
                System.out.println("Phone number:"+abook.getPhoneNumber());
    
     }
    
    }
