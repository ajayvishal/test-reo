package com.spring.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.service.CourierService;

public class Driver {

	public static void main(String[] args) {
		
		InputStreamReader ir=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(ir);
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		CourierService cs=(CourierService)context.getBean("abc");
		int count=0;
		try {
			int courierId;
			int weight;
			String city;
			System.out.println("Enter the courier ID:");
			courierId=Integer.parseInt(br.readLine());
			System.out.println("Enter the total weight of parcel:");
			weight=Integer.parseInt(br.readLine());
			System.out.println("Enter the city:");
			city=br.readLine();
			double charge=cs.calculateCourierCharge(courierId,weight,city);
			
			if(weight<0||weight>1000) {
				count=1;
			}
			if(count!=1) {
				System.out.println(charge);
			}
		}catch (NumberFormatException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
