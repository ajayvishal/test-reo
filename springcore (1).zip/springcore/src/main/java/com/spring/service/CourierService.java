package com.spring.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.spring.bo.CourierBO;
import com.spring.exception.InvalidParcelWeightException;
import com.spring.model.Courier;

public class CourierService {

	private CourierBO cBoObj;

	public CourierBO getcBoObj() {
		return cBoObj;
	}

	public void setcBoObj(CourierBO cBoObj) {
		this.cBoObj = cBoObj;
	}

	public double calculateCourierCharge(int courierId, int weight, String city) {
		
		double courierCharge=0;
		
		if(weight<0||weight>1000) {
			try {
				InvalidParcelWeightException ip=new InvalidParcelWeightException ("Invalid Parcel Weight");
				
			}catch (Exception ip) {
				// TODO: handle exception 
			}
		}
		else {
			ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
			Courier c=(Courier)context.getBean("cou");
			courierCharge=cBoObj.calculateCourierCharge(c,city);
		}
		
		return courierCharge;
	}

}
