package com.spring.bo;
import java.util.Map;
import com.spring.exception.InvalidParcelWeightException;
import com.spring.model.Courier;
import com.spring.model.ServiceChargeInfo;

public class CourierBO {

	public double calculateCourierCharge(Courier cObj,String city) {
		int weight=cObj.getWeight();
		float chargePerKg=cObj.getChargePerKg();
		double courierCharge=0.0;
		
		ServiceChargeInfo serviceCharge=cObj.getServiceCharge();
		Map<String,Float> locationServiceCharge=serviceCharge.getLocationServiceCharge();
		double appropriateServiceCharge=0;
		
		if(locationServiceCharge.get(city)!=null) {
			appropriateServiceCharge=locationServiceCharge.get(city);
			courierCharge=weight*chargePerKg;
			courierCharge=courierCharge + appropriateServiceCharge;
		}else {
			courierCharge =weight*chargePerKg;
		}
		return courierCharge;
	}
}
